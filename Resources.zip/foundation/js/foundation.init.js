﻿$(document).foundation();
console.log('Prelude to Foundation');